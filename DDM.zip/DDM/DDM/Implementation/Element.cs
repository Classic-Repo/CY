﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DDM.Implementation
{
    public class Element : Abstraction.IElement
    {
        public string Name
        {
            get;
            set;
        }

        public string Symbol
        {
            get;
            set;
        }

        public StringBuilder Message
        {
            get;
            set;
        }

        public bool ValidateSymbol()
        {

            bool ValidSym = false;

            Message = Message ?? new StringBuilder();

            Message.Clear();

            if (Symbol.Length != 2)
            {
                Message.AppendLine("Symbol length is invalid");
            }
            Symbol.ToList().ForEach((x) => {
                if (!Name.ToLower().Contains(x.ToString().ToLower()))
                    Message.AppendLine($"Symbol letter { x } is not contained in the element");
            });

            if ((Name.Count((x) => Name.ToLower().IndexOf(x.ToString().ToLower()) > 1) > 1
                && (Name.ToLower().IndexOf(Symbol[0].ToString().ToLower()) <= Name.ToLower().IndexOf(Symbol[1].ToString().ToLower())) 
                || (Name.ToLower().Contains(Symbol[1].ToString().ToLower()) 
                && !(Name.ToLower().IndexOf(Symbol[0].ToString().ToLower()) <= Name.ToLower().IndexOf(Symbol[1].ToString().ToLower()))
                )))
                      Message.AppendLine("Symbol letters are not in order in the element name");

            if ((string.Compare(Symbol[0].ToString(), Symbol[1].ToString(), true) == 0) && Name.Count((x) => Symbol[0].ToString().ToLower().Contains(x.ToString().ToLower())) != 2)
                Message.AppendLine("Symbol with the same letters must appear twice in the element name");

           if(!char.IsUpper(Symbol[0]))
                Message.AppendLine("First Character of the symbol must be upper case");

           if (!char.IsLower(Symbol[1]))
                Message.AppendLine("Second Character of the symbol must be lower case");


            ValidSym = Message.Length == 0;

            return ValidSym;
        }


    }
}
