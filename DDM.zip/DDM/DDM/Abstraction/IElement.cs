﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DDM.Abstraction
{
    public interface IElement
    {
        string Name { get; set; }
        string Symbol { get; set; }
        StringBuilder Message { get; set; }
        bool ValidateSymbol();
    }
}
