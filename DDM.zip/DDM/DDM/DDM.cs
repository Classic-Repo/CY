﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DDM
{
    public partial class DDM : Form
    {
        public DDM()
        {
            InitializeComponent();
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                Abstraction.IElement elm = new Implementation.Element();
                elm.Name = txtElement.Text;
                elm.Symbol = txtSymbol.Text;
                lblValid.Text = elm.ValidateSymbol().ToString();
                MessageBox.Show(elm.Message.Length > 0 ? elm.Message.ToString() : "Valid");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
