﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeBase.DatabaseClient
{
    public abstract class AbstractConnectionObjectModel<T> : IDisposable where T : new()
    {
        /// <summary>
        /// Working handler class of the Data Access Layer
        /// </summary>

        #region types and variables declarations

        protected IDatabaseConnection<T> _DatabaseConnection = null;

        #endregion
 
        #region Property return Handlers

       public abstract ConnectionModel<T>.TransactionType TSQLTYPE
        {
            get;
            set;
        }

        public abstract string ParameterSymbol
        {
            get;
            set;
        }

        protected internal abstract IDatabaseConnection<T> DatabaseConnection
        {
            get;
            set;
        }

        public abstract string ConnectionString
        {
            get;
            set;
        }

        public abstract System.Data.CommandType CommandType
        {
            get;
            set;
        }

        public abstract string CommandText
        {
            get;
            set;
        }

        public abstract System.Data.IDbConnection ExternalConnection
        {
            get;
            set;
        }

        public abstract int CommandTimeout
        {
            get;
            set;
        }

       public abstract Object GetInstance
       {
           get;
       }

        #region Constructors

        #endregion

        #region Functional Handlers

       public abstract string ConfigurationManagerConnectionString(string Key);

       public abstract string ConfigurationManagerConnectionString(int Index);

       public abstract void SetCommandParameter<P>(string ParameterName, P ParameterValue, System.Data.DbType ParameterType, short ParameterSize, System.Data.ParameterDirection Direction, string SourceColumn);

       public abstract int ExcecuteNoneQuery();

       public abstract S ExecuteScalar<S>();

       public abstract System.Data.DataSet ExcecuteDataset<D>(string Name);

       public abstract System.Data.IDataReader ExecuteDatareader(System.Data.CommandBehavior Behavior);

       public abstract System.Data.DataTable ExecuteDataTable(string Name, System.Data.CommandBehavior Behavior);

       public abstract System.Data.DataTable GetDatabaseSchemaTable(string Name, System.Data.CommandBehavior Behavior);

       public abstract Boolean UseableConnection
       {
           get;
       }
        
        public abstract Boolean ExecuteLinQ<K>(K LnQquery, out K LnQResult);

        public abstract Boolean LoadQueryFile(string FileNameAndPath);

        public abstract Boolean ValidateDataTable(System.Data.DataTable dt, Boolean IgnoreEmptyTable);

        public abstract Boolean ValidateDataSet(System.Data.DataSet ds, Int16 Indx, Boolean IgnoreEmptyTable);

        public abstract void ClearParameters();

        public abstract void RemoveParameter(string ParameterName);

        public abstract ParameterType GetParameterValue<ParameterType>(string ParameterName);

        public abstract void Dispose();

        #endregion


        #endregion

        #region IDisposable Members
        
        void IDisposable.Dispose()
        {
            Dispose();
        }
       

        #endregion
    }

}
