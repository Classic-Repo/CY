﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeBase.DatabaseClient
{

    public sealed partial class ConnectionModel<T>: IDatabaseConnection<T>,IDisposable where T : new()
    {

        #region Enumurator/Strctures

        public enum TransactionType : byte { SELECT = 0, INSERT = 1, UPDATE = 2, DELETE = 3 };

        #endregion 

        #region Variables/Fields

        private string _ConnectionString = string.Empty;
        private Int32 _CommandTimeout = 500;
        private System.Data.IDbConnection _Connection = null;
        private System.Data.IDbConnection _ExternalConnection = null;
        private System.Data.IDbCommand _Command = null;
        private System.Data.CommandType _CommandType;
        private string _CommandText;
        private System.Data.IDbDataAdapter _Da = null;
        private string _ParameterSymbol = string.Empty;
        private TransactionType _TSQLTYPE;

        #endregion

        #region IDatabaseConnection Members

        #region Properties

        #region IDatabaseConnection<T> Members


        #region TSQLTYPE

        private TransactionType TSQLTYPE
        {
            get
            {
                return _TSQLTYPE;
            }
            set
            {
                _TSQLTYPE = value;
            }
        }

        ConnectionModel<T>.TransactionType IDatabaseConnection<T>.TSQLTYPE
        {
            get
            {
                return TSQLTYPE;
            }
            set
            {
                TSQLTYPE = value;
            }
        }

        #endregion

        #endregion

        #region Connection String

        private string ConnectionString
        {
            get
            {
            return _ConnectionString;
            }
            set
            {
                _ConnectionString = value;
            }
        }

       string IDatabaseConnection<T>.ConnectionString
        {
            get
            {
                return ConnectionString;
            }
            set
            {
                ConnectionString = value;
            }
        }
        #endregion

        #region CommandTimout

    private   int CommandTimeout
       {
           get
           {
               return _CommandTimeout;
           }
           set
           {
               _CommandTimeout = value;
           }
       }


        int IDatabaseConnection<T>.CommandTimeout
        {
            get
            {
                return CommandTimeout;
            }
            set
            {
                CommandTimeout = value;
            }
        }
       #endregion

        #region CommandType
        System.Data.CommandType CommandType
        {
            get
            {
                return _CommandType;
            }
            set
            {
                _CommandType = value;
            }
        }

        System.Data.CommandType IDatabaseConnection<T>.CommandType
        {
            get
            {
                return CommandType;
            }
            set
            {
                CommandType = value;
            }
        }
        #endregion

        #region CommandText

      private  string CommandText
        {
            get
            {
                return _CommandText;
            }
            set
            {
                _CommandText = value;
            }
        }

        string IDatabaseConnection<T>.CommandText
        {
            get
            {
                return CommandText;
            }
            set
            {
                CommandText = value;
            }
        }

     #endregion

        #region External Connection

        System.Data.IDbConnection ExternalConnection
        {
            get
            {
                return _ExternalConnection;
            }
            set
            {
                _ExternalConnection = value;
            }
        }

        System.Data.IDbConnection IDatabaseConnection<T>.ExternalConnection
        {
            get
            {
                return ExternalConnection;
            }
            set
            {
                ExternalConnection = value;
            }
        }

        #endregion

        #region Connection Object

        System.Data.IDbConnection Connection
        {
            get
            {
                if (ExternalConnection != null)
                {
                    if (_Command != null)
                    {
                        _Command.Connection.Close(); _Command.Connection.Dispose(); _Command.Connection = null;
                        _Command.Dispose(); _Command = null;
                    }

                    if (_Connection != null) { _Connection.Close(); _Connection.Dispose(); _Connection = null; }

                    _Da = null;

                    _Connection = ExternalConnection;
                }
                else
                {
                    if (_Connection == null)
                    {
                        _Connection = (System.Data.IDbConnection)new T();
                        _Connection.ConnectionString = ConnectionString;
                    }
                }

                if (_Connection.State != System.Data.ConnectionState.Open)
                {
                    _Connection.Open();
                }

                return _Connection;
            }
        }

        System.Data.IDbConnection IDatabaseConnection<T>.Connection
        {
            get
            {
                return Connection;
            }
        }

        #endregion

        #region Command Object

        System.Data.IDbCommand Command
        {
            get
            {
                if (_Command == null)
                {
                    _Command = Connection.CreateCommand();
                }
                _Command.CommandTimeout = CommandTimeout;
                _Command.CommandType = CommandType;
                _Command.CommandText = CommandText;

                return _Command;
            }

        }

        System.Data.IDbCommand IDatabaseConnection<T>.Command
        {
            get
            {
                return Command;
            }

        }

        #endregion

        #region ParameterSymbol

      private  string ParameterSymbol
        {
            get
            {
                return _ParameterSymbol;
            }
            set
            {
                _ParameterSymbol = value;
            }
        }

        string IDatabaseConnection<T>.ParameterSymbol
        {
            get
            {
                return ParameterSymbol;
            }
            set
            {
                ParameterSymbol = value;
            }
        }

        #endregion

        #endregion

        #region Methods

        void IDatabaseConnection<T>.AddParameter<K>(string ParameterName, K ParameterValue, System.Data.DbType ParameterType, short ParameterSize, System.Data.ParameterDirection Direction, string SourceColumn)
        {
            System.Data.IDbDataParameter Param = null;
            // Do size validation
            if (ParameterSize > 1) { if (ParameterValue.ToString().Length > ParameterSize) { throw new Exception("Parameter (" + ParameterName + ") size (" + ParameterValue.ToString().Length + ") Exceeds allocated size(" + ParameterSize + ")"); } }

            Param = Command.CreateParameter();
            Param.ParameterName = ParameterSymbol + ParameterName;
            Param.Size = ParameterSize;
            Param.Value = ParameterValue;
            Param.DbType = ParameterType;
            Param.Direction = Direction;
            Param.SourceColumn = SourceColumn;
            Command.Parameters.Add(Param);
        }

        
        System.Data.IDbDataAdapter IDatabaseConnection<T>.Da<L>()
        {
            if (_Da == null)
            {
                _Da = (System.Data.IDbDataAdapter)((L)Activator.CreateInstance<L>());
            }

            if (TSQLTYPE == ConnectionModel<T>.TransactionType.SELECT)
            {
                _Da.SelectCommand = Command;
            }
            else if (TSQLTYPE == ConnectionModel<T>.TransactionType.INSERT)
            {
                _Da.InsertCommand = Command;
            }
            else if (TSQLTYPE == ConnectionModel<T>.TransactionType.UPDATE)
            {
                _Da.UpdateCommand = Command;
            }
            else if (TSQLTYPE == ConnectionModel<T>.TransactionType.DELETE)
            {
                _Da.DeleteCommand = Command;
            }

            return _Da;
        }

        bool IDatabaseConnection<T>.ExecuteLinQ<K>(K LnQquery, out K LnQResult)
        {
            Boolean _Res = false;
            LnQResult = LnQquery;
            _Res = true;
            return _Res;
        }

        #region IDisposable Members

       public void Dispose()
        {
            if (_Command != null)
            {
                _Command.CreateParameter();
                _Command.Connection.Close(); _Command.Connection.Dispose(); _Command.Connection = null;
                _Command.Dispose(); _Command = null;
            }

            if (_Connection != null) { _Connection.Close(); _Connection.Dispose(); _Connection = null; }

            _Da = null;

            if (_ExternalConnection != null) { _ExternalConnection.Close(); _ExternalConnection.Dispose(); _ExternalConnection = null; }
            GC.SuppressFinalize(this);
        }

        #endregion

        #endregion

        #endregion
 
    }
}
