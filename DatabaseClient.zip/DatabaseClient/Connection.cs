﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeBase.DatabaseClient
{

    /// <summary>
    /// The parameter T refers to the connection Client to the database
    /// </summary>
    /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
    public partial class Connection<T> : AbstractConnectionObjectModel<T>, IDisposable where T : new()
    {

        #region Properties

        /// <summary>
        /// Interface object for the connection model.
        /// Adapter used to call the Connection model exposed methods
        /// </summary>
        /// 

        private string _ConnectionString
        {
            get;
            set;
        }

        protected internal override IDatabaseConnection<T> DatabaseConnection
        {
            get
            {
                if (_DatabaseConnection == null)
                {
                    _DatabaseConnection = (IDatabaseConnection<T>)new ConnectionModel<T>();
                    _DatabaseConnection.ConnectionString = ConnectionString;
                }
                return _DatabaseConnection;
            }
            set
            {
                _DatabaseConnection = value;
            }
        }

        public override string ConnectionString
        {
            get
            {
                return _ConnectionString;
            }
            set
            {
                _ConnectionString = value;
                _DatabaseConnection?.Dispose();
                _DatabaseConnection = null;
            }
        }

        /// <summary>
        /// returns the current instance of the DatabaseConnection
        /// </summary>
        public override Object GetInstance
        {
            get
            {
                return _DatabaseConnection;
            }
        }

        /// <summary>
        /// Set  the transaction type of the query/statement 
        /// </summary>
        public override ConnectionModel<T>.TransactionType TSQLTYPE
        {
            get
            {
                return DatabaseConnection.TSQLTYPE;
            }
            set
            {
                DatabaseConnection.TSQLTYPE = value;
            }
        }

        /// <summary>
        /// parameter symbol of the db type of current connection instance
        /// </summary>
        public override string ParameterSymbol
        {
            get
            {
                return DatabaseConnection.ParameterSymbol;
            }
            set
            {
                DatabaseConnection.ParameterSymbol = value;
            }
        }

        /// <summary>
        /// Connection string of current database instances
        /// </summary>
        /// 

        public override string ConfigurationManagerConnectionString(string Key)
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings[Key].ConnectionString;
        }

        public override string ConfigurationManagerConnectionString(int Index)
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings[Index].ConnectionString;
        }

        /// <summary>
        /// Command type of current connection object. Tect/Storedprocedure or Tables Direct
        /// </summary>
        public override System.Data.CommandType CommandType
        {
            get
            {
                return DatabaseConnection.CommandType;
            }
            set
            {
                DatabaseConnection.CommandType = value;
            }
        }

        /// <summary>
        /// CommandText property of the connection Command
        /// </summary>
        public override string CommandText
        {
            get
            {
                return DatabaseConnection.CommandText;
            }
            set
            {
                DatabaseConnection.CommandText = value;
            }
        }

        /// <summary>
        /// External instance which is passed by user
        /// Database Client will use this connection and Dispose it's Default instantiated Connection
        /// </summary>
        public override System.Data.IDbConnection ExternalConnection
        {
            get
            {
                return DatabaseConnection.ExternalConnection;
            }
            set
            {
                DatabaseConnection.ExternalConnection = value;
            }
        }

        /// <summary>
        /// Server TimeOut upon request of execution
        /// </summary>
        public override int CommandTimeout
        {
            get
            {
                return DatabaseConnection.CommandTimeout;
            }
            set
            {
                DatabaseConnection.CommandTimeout = value;
            }
        }



        #endregion

        #region Abstract methods implementations 
        /// <summary>
        /// Set the command parameters of the current command object instance
        /// </summary>
        /// <typeparam name="P">depends on the type of connection passed as T e.g System.Dat.SqlClient.SqlParameter</typeparam>
        /// <param name="ParameterName">Name of the parameter</param>
        /// <param name="ParameterValue">Value of the Parameter</param>
        /// <param name="ParameterType">Type of the Parameter eg DbTyp.In32/DbType.String</param>
        /// <param name="ParameterSize">Size of the Parameter</param>
        /// <param name="Direction">Type of the Parameter Direction eg Output or Input</param>
        /// <param name="SourceColumn">Column name of the target table relative to this parameter</param>
        public override void SetCommandParameter<P>(string ParameterName
                                                    , P ParameterValue
                                                    , System.Data.DbType ParameterType = System.Data.DbType.Object
                                                    , short ParameterSize = 0
                                                    , System.Data.ParameterDirection Direction = System.Data.ParameterDirection.InputOutput
                                                    , string SourceColumn = "")
        {
            DatabaseConnection.AddParameter<P>(ParameterName
                                              , ParameterValue
                                              , ParameterType
                                              , ParameterSize
                                              , Direction
                                              , SourceColumn);
        }

        /// <summary>
        /// Returns the Parameter value that was set as an output Direction.
        /// </summary>
        /// <typeparam name="ParameterType">Primitive/Derived type to cast result type conversion to</typeparam>
        /// <param name="ParameterName">Name of the Parameter to be interogated in the collection</param>
        /// <returns>Desired return type to the caller instance</returns>
        public override ParameterType GetParameterValue<ParameterType>(string ParameterName)
        {
            if (!ParameterName.Contains(ParameterSymbol))
            {
                ParameterName = ParameterSymbol + ParameterName;
            }
            return (ParameterType)(DatabaseConnection.Command.Parameters.Contains(ParameterName) ? 
                   (ParameterType)Convert.ChangeType(((System.Data.IDbDataParameter)DatabaseConnection.Command.Parameters[ParameterName]).Value.ToString(), typeof(ParameterType)) : default(ParameterType));
        }


        /// <summary>
        /// Clear Command Prameters for object instance reuse
        /// </summary>
        public override void ClearParameters()
        {
            DatabaseConnection.Command.Parameters.Clear();
        }


        /// <summary>
        /// Remove Parameter from the Parameter collection in the command object instance
        /// </summary>
        /// <param name="ParameterName">Name of the Parameter to be removed</param>
        public override void RemoveParameter(string ParameterName)
        {
            if (!ParameterName.Contains(ParameterSymbol))
            {
                ParameterName = ParameterSymbol + ParameterName;
            }

            if (DatabaseConnection.Command.Parameters.Contains(ParameterName))
            {
                DatabaseConnection.Command.Parameters.RemoveAt(ParameterName);
            }
        }

        /// <summary>
        /// Used to Execute insert, update, delete T-SQL Statements
        /// </summary>
        /// <returns>Valuetype of type integer will be returned from this method</returns>
        public override int ExcecuteNoneQuery()
        {
            int vlu = DatabaseConnection.Command.ExecuteNonQuery();
            return vlu;
        }

        /// <summary>
        /// Returns singular result from query and casts to specified Generic type Parameter
        /// </summary>
        /// <typeparam name="S">Return type cast Parameter</typeparam>
        /// <returns>Returned type to the caller instance</returns>
        public override S ExecuteScalar<S>()
        {
            var obj = DatabaseConnection.Command.ExecuteScalar();
            return obj == null ? default(S) : (S)Convert.ChangeType(obj, typeof(S));
        }

        /// <summary>
        /// Pass the adapter type as a generic type to the method
        /// </summary>
        /// <typeparam name="D">Type of adapter(e.g. System.Data.SqlClient.SqlDataAdapter or System.Data.OracleClient etc...)</typeparam>
        /// <returns>Dataset</returns>
        public override System.Data.DataSet ExcecuteDataset<D>(string Name)
        {
            System.Data.DataSet ds = null;

            if (Name != string.Empty)
            {
                ds = new System.Data.DataSet(Name);
            }
            else
            {
                ds = new System.Data.DataSet();
            }

            DatabaseConnection.Da<D>().Fill(ds);

            return ds;
        }

        /// <summary>
        /// Returns a DataReader
        /// </summary>
        /// <param name="Behavior">System.Data.CommandBehavior</param>
        /// <returns>DataReader</returns>
        public override System.Data.IDataReader ExecuteDatareader(System.Data.CommandBehavior Behavior)
        {
            return DatabaseConnection.Command.ExecuteReader(Behavior);
        }

        /// <summary>
        /// Start a new IDB transaction 
        /// </summary>
        public override void StartTraction()
        {
            DatabaseConnection.StartTraction();
        }

        /// <summary>
        /// Commit the IDB transaction
        /// </summary>
        public override void CommitTransaction()
        {
            DatabaseConnection.CommitTransaction();
        }

        /// <summary>
        /// Rollback the IDB transaction
        /// </summary>
        public override void RollBackTraction()
        {
            DatabaseConnection.RollBackTraction();
        }

        /// <summary>
        /// This methods returns A DataTable which is loaded from a DataReader object. Although this method is functional use the specification
        /// public override System.Data.DataSet ExcecuteDataset<D>(string Name) Method instead(Much faster execution)
        /// </summary>
        /// <param name="Name">Name of the DataTable</param>
        /// <param name="Behavior">System.Data.CommandBehavior which is passed to the DataReader loading the DataTable</param>
        /// <returns>DataTable</returns>
        public override System.Data.DataTable ExecuteDataTable(string Name, System.Data.CommandBehavior Behavior)
        {
            System.Data.DataTable dt = new System.Data.DataTable();

            if (Name != string.Empty)
            {
                dt.TableName = Name;
            }

            dt.Load(ExecuteDatareader(Behavior));

            return dt;
        }

        /// <summary>
        /// Returns the schema of the Database Table. 
        /// </summary>
        /// <param name="Name">Name of the DataTable<</param>
        /// <param name="Behavior">System.Data.CommandBehavior which is passed to the DataReader loading the DataTable</param>
        /// <returns>DataTable</returns>
        public override System.Data.DataTable GetDatabaseSchemaTable(string Name, System.Data.CommandBehavior Behavior)
        {
            System.Data.DataTable dt = new System.Data.DataTable();

            if (Name != string.Empty)
            {
                dt.TableName = Name;
            }

            dt = ExecuteDatareader(Behavior).GetSchemaTable();

            return dt;
        }

        /// <summary>
        /// Returns a boolean indication if the connection can be used.
        /// </summary>
        public override bool UseableConnection
        {
            get
            {
                return DatabaseConnection.Connection.State == System.Data.ConnectionState.Open ? true : false;
            }
        }

        /// <summary>
        /// Executes a linQ query
        /// </summary>
        /// <typeparam name="K">Generic Return Type</typeparam>
        /// <param name="LnQquery">The passed linq query</param>
        /// <param name="LnQResult">Results collections to be returned to caller</param>
        /// <returns>Generic Type</returns>
        public override bool ExecuteLinQ<K>(K LnQquery, out K LnQResult)
        {
            return DatabaseConnection.ExecuteLinQ<K>(LnQquery, out LnQResult);
        }

        /// <summary>
        /// Executes a query stored in a file and returns a boolean value indicating if the file have been found and read successfully
        /// </summary>
        /// <param name="FileNameAndPath">The file name and Path of the file</param>
        /// <returns>boolean</returns>
        public override bool LoadQueryFile(string FileNameAndPath)
        {
            bool _Res = false;

            System.IO.FileInfo Filn = new System.IO.FileInfo(FileNameAndPath);

            if (Filn.Exists)
            {
                this.CommandText = Filn.OpenText().ReadToEnd();
                _Res = true;
            }

            return _Res;
        }


        /// <summary>
        /// Validates if the Dataset/Table is empty and also has any Data collections in the object instance.
        /// will return false if the datable is not instantiated.
        /// </summary>
        /// <param name="dt">DataTable to be evaluated</param>
        /// <param name="IgnoreEmptyTable">indicates if the empty Datatable collection should be ignored</param>
        /// <returns>boolean</returns>
        public override bool ValidateDataTable(System.Data.DataTable dt, bool IgnoreEmptyTable)
        {
            Boolean _res = false;
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    _res = true;
                }
                else
                {
                    _res = IgnoreEmptyTable;
                }
            }
            return _res;
        }

        /// <summary>
        /// Validate Dataset instance, and evaluetes it's table Data collections 
        /// </summary>
        /// <param name="ds">Dataset Instance passed</param>
        /// <param name="Indx">Table index of the Dataset</param>
        /// <param name="IgnoreEmptyTable">indicates if the empty Datatable collection should be ignored</param>
        /// <returns>boolean</returns>
        public override Boolean ValidateDataSet(System.Data.DataSet ds, Int16 Indx, Boolean IgnoreEmptyTable)
        {

            Boolean _res = false;

            if (ds != null)
            {
                if ((ds.Tables.Count - Indx) > 0)
                {
                    _res = ValidateDataTable(ds.Tables[Indx], IgnoreEmptyTable);
                }
            }

            return _res;
        }

        /// <summary>
        /// Dispose objects used by current connection instance
        /// </summary>
        public override void Dispose()
        {
            DatabaseConnection.Dispose(); DatabaseConnection = null;
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}
