﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeBase.DatabaseClient
{

    /// <summary>
    /// Client is used to collect connections to Database servers,
    /// and there are different ways which can be used to call this class
    /// 1. Using the struct to instantiate connections
    /// 2. Using the Class instance directly
    /// </summary>

   public partial class Client:IDisposable
   {

       #region Structs
       /// <summary>
       /// Used to instantiate a connection and can be added to the list of collections using the List Property(List<Object> ConnectionClientList)
       /// </summary>
       /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
       public struct ConnectionClient<T> where T: new()
       {
          public string Key;
          public ConnectionAbstract<T> Connection;
       }

       #endregion


       #region Variables
       /// <summary>
       /// Can be used by external Members that directly inherit this class.
       /// Stores Database Connections
       /// </summary>
       protected internal List<object> _ConnectionClientList = null;

       #endregion

       #region Properties

       /// <summary>
       /// Returns the of ConnectionClients count in the Collection. 
       /// </summary>
       public int ConnectionClients
       {
           get 
           { 
                 return ConnectionClientList.Count;
           }
       }

       /// <summary>
       /// Returns and sets _ConnectionClientList
       /// </summary>
       protected List<Object> ConnectionClientList
       {
           get 
           {
               if (_ConnectionClientList == null)
               {
                   _ConnectionClientList = new List<Object>();
               }
               return _ConnectionClientList;
           }
           set
           {
               _ConnectionClientList = value;
           }
       }

       #endregion

       #region Add
       /// <summary>
       /// Adds a Database Connection to the Generic List using the public struct ConnectionClient<T>.
       /// </summary>
       /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
       /// <param name="ConnectionClient">public struct ConnectionClient<T> </param>
       public void AddConnectionClient<T>(ConnectionClient<T> ConnectionClient) where T:new()
       {
           RemoveConnectionClient<T>(ConnectionClient.Key);
           ConnectionClientList.Add(ConnectionClient);
       }
       /// <summary>
       /// Overloads public void AddConnectionClient<T>(ConnectionClient<T> ConnectionClient) where T:new().
       /// Adds a Database Connection<T> to the Generic List using the public struct ConnectionClient<T> Key.
       /// </summary>
       /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
       /// <param name="Key">Public struct ConnectionClient<T> Key where Key is of type string</param>
       public void AddConnectionClient<T>(string Key) where T: new()
       {
         RemoveConnectionClient<T>(Key);
         ConnectionClientList.Add(new ConnectionClient<T> { Key = Key, Connection = new Connection<T>() });
       }

       #endregion

       #region Remove
       /// <summary>
       /// Overloads  public void RemoveConnectionClient<T>(ConnectionClient<T> ConnectionClient) where T:new().
       /// Disposes and removes Database Client Connection<T> from the Generic List using the public struct ConnectionClient<T> Key.
       /// </summary>
       /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
       /// <param name="Key">Public struct ConnectionClient<T> Key where Key is of type string</param>
       public void RemoveConnectionClient<T>(string Key) where T : new()
       {
            if (ConnectionClients > 0)
            {
                ConnectionClientList.Where(x =>
                ((ConnectionClient<T>)x).Key == Key).ToList()
                .ForEach(j =>
                {
                    ((ConnectionClient<T>)j).Connection.Dispose();
                    ConnectionClientList.Remove(j);
                });
            }
       }

       /// <summary>
       /// Disposes and removes Database Client Connection<T> of T connections from the Generic List where T is Generic Type.
       /// </summary>
       /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
       public void RemoveAllConnectionClient<T>() where T:new()
       {
            if (ConnectionClients > 0)
            {
                ConnectionClientList.ForEach(x =>
               {
                   ((ConnectionClient<T>)x).Connection.Dispose();
                   ConnectionClientList.Remove(x);
               });
            }
       }

       #endregion

       #region Get
       /// <summary>
       /// Returns a Database connection with a specific key, if not available then a new instance is created.
       /// </summary>
       /// <typeparam name="T">e.g  System.Data.OracleClient.OracleDataAdapter or  System.Data.SqlClient.SqlConnection etc..</typeparam>
       /// <param name="Key">Public struct ConnectionClient<T> Key where Key is of type string</param>
       /// <returns>ConnectionClient<T></returns>
       public ConnectionClient<T> GetConnectionClient<T>(string Key) where T : new()
       {
            ConnectionClient<T>? ConnectionClient = null;

            if (ConnectionClients > 0)
                ConnectionClient = (ConnectionClient<T>)ConnectionClientList.Where(x => ((ConnectionClient<T>)x).Key == Key).FirstOrDefault();

            if(!ConnectionClient.HasValue)
            {
                ConnectionClient =  new ConnectionClient<T>() { Key = Key, Connection = new Connection<T>() };
                this.AddConnectionClient<T>(ConnectionClient.Value);
            }
           return ConnectionClient.Value;
       }
       /// <summary>
       /// This Method must be called to check if all connections have be removed and dispose.
       /// </summary>
       /// <returns>string</returns>
       public string CheckUndisposedConnectionClients()
       {
           StringBuilder sb = new StringBuilder();
           if (ConnectionClients > 0)
           {
                ConnectionClientList.ForEach(x => { sb.AppendLine(">" + ((dynamic)x).Key + " Not Disposed."); });
           }
           return sb.ToString();
       }



       #endregion

       #region IDisposable Members

       public void Dispose()
       {
            foreach(dynamic obj in ConnectionClientList)
            {
                obj.Connection.Dispose();
                obj.Connection = null;
            }
            ConnectionClientList.Clear();
            ConnectionClientList = null;

          GC.SuppressFinalize(this);
       }

       #endregion
    }
}
