﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CodeBase.DatabaseClient
{

    public interface IDatabaseConnection<T>:IDisposable where T : new()
    {

        ConnectionModel<T>.TransactionType  TSQLTYPE
        {
         get;
         set;
        }

       string ConnectionString
        {
            get;
            set;
        }

        int CommandTimeout
        {
            get;
            set;
        }

        System.Data.IDbConnection Connection
        {
            get;
        }

        System.Data.IDbConnection ExternalConnection
        {
            get;
            set;
        }

        System.Data.IDbCommand Command
        {
            get;
        }

       System.Data.CommandType CommandType
        {
            get;
            set;
        }

       string CommandText
        {
            get;
            set;
        }

        string ParameterSymbol
        {
            get;
            set;
        }


        void AddParameter<M>(string ParameterName, M ParameterValue, System.Data.DbType ParameterType, short ParameterSize, System.Data.ParameterDirection Direction, string SourceColumn);

        System.Data.IDbDataAdapter Da<L>();

        Boolean ExecuteLinQ<J>(J LnQquery, out J LnQResult);

    }
}
