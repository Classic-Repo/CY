﻿(function () {
angular
    .module('app.menu')
    .component('menu', {
        controller: menuController,
        controllerAs: 'vm',
        templateUrl: '/client/app/menu/menu.component.html'
    });

    menuController.$inject = ['menuService'];

    function menuController(menuService) {

    var vm = this;

    getSettings();

    vm.buildBanks = buildBanks;
    vm.LoadItems = LoadItems;
    vm.buildMenu = buildMenu;
    vm.loadPersonalDetailsKeys = loadPersonalDetailsKeys;
    vm.LoadAddressKeys = LoadAddressKeys;
    vm.loadPersonalDetails = loadPersonalDetails;
    vm.loadAddressDetails = loadAddressDetails;

    function getSettings() {
        menuService.getSettings().then(function (result) {
            vm.menu = result;
            buildMenu();
        });
    }


    function buildMenu()
    {
        vm.manDiv = document.getElementById("MenuItems");

        vm.divClient = document.createElement("div");
        vm.divClient.style.display = 'none';

        var maiAchore = document.createElement("a");
        maiAchore.innerText = "Client";

        maiAchore.onclick = function () {

            if (vm.divClient.style.display == 'none') {

                vm.divClient.innerHTML = '';

                var obj = Object.keys(vm.menu).map(function (key) { return vm.menu[key]; });

                var client = Object.keys(obj[0]).map(function (key) { return [key, obj[0][key]]; });

                for (var i = 0; i < client.length; i++) {

                    var name = client[i][0];
                    var clientinfo = client[i][1];

                    divName = document.createElement("div");

                    var ancor = document.createElement("a");

                    ancor.innerText = name;

                    addClickHandler(ancor, clientinfo, divName);

                    divName.appendChild(ancor);
                    vm.divClient.appendChild(divName);
                }

                vm.divClient.style.display = 'block';
            }
            else
            {
                vm.divClient.style.display = 'none';
            }

            vm.manDiv.insertBefore(vm.divClient, vm.manDiv.childNodes[1]);
        }
      
        vm.manDiv.appendChild(maiAchore);

        loadBanks();
    }

    function addClickHandler(elem, clientinfo, divName) {
        elem.addEventListener('click', function (e) {
            var Load = true;
            if (vm.previous === elem.innerText) {
                Load = false;
            }
            else {
                vm.previous = elem.innerText;
            }

            LoadItems(clientinfo, divName, Load);

        }, false);
    }



    function loadBanks()
    {
        vm.divBank = document.createElement("div");
        
        var ancor = document.createElement("a");
        ancor.innerText = "Bank";
        ancor.onclick = function () { vm.buildBanks(); } 
        
        vm.divBankItems = document.createElement("div");
        vm.divBankItems.style.display = 'none'

        vm.divBank.appendChild(ancor)
        vm.divBank.appendChild(vm.divBankItems);
        vm.manDiv.appendChild(vm.divBank);
    }

    function buildBanks() {

        vm.divBankItems.innerHTML = '';
    
        if (vm.divBankItems.style.display == 'none') {

            var bank = Object.keys(vm.menu.bank).map(function (key) { return vm.menu.bank[key]; });

            for (var i = 0; i < bank.length; i++) {
                var list = document.createElement("a");
                list.innerText = bank[i];
                var brk = document.createElement("br");
                vm.divBankItems.appendChild(list);
                vm.divBankItems.appendChild(brk)
            }
            vm.divBankItems.style.display = 'block';
        }
        else
        {
            vm.divBankItems.style.display = 'none';
        }
        
    }

    function LoadItems(clientinfo, divName, Load) {

        divName.style.display = 'block';

        if (Load) {

            divPersonalDetails = document.createElement("div");
            divAddressDetails = document.createElement("div");

            divPersonalDetails.style.display = 'none'
            divAddressDetails.style.display = 'none'

            loadPersonalDetailsKeys(clientinfo.personalDetails, divPersonalDetails);
            LoadAddressKeys(clientinfo.addresDetails, divAddressDetails);

            divName.appendChild(divPersonalDetails);
            divName.appendChild(document.createElement("p"));
            divName.appendChild(divAddressDetails);
            vm.divClient.appendChild(divName);
        }
    }

    function loadPersonalDetailsKeys(obj,divPersonalDetails) {

        divPersonalDetails.innerHTML = '';

        var ancorPersonalKey = document.createElement("a");
        ancorPersonalKey.innerHTML = "Personal Details";

        ancorPersonalKey.onclick = function () {
            loadPersonalDetails(obj);
        } 
        
        divPersonalDetails.appendChild(ancorPersonalKey);
        divPersonalDetails.appendChild(document.createElement("p"));
        divPersonalDetails.style.display = 'block';
    }

    function loadPersonalDetails(obj) {

        var div = document.getElementById("Divselect");;
        div.innerHTML = '';
        var ancorContactNumber = document.createElement("a");
        ancorContactNumber.innerHTML = obj.ContactNumber;

        var ancorGender = document.createElement("a");
        ancorGender.innerHTML = obj.Gender;

        div.appendChild(ancorContactNumber);
        div.appendChild(document.createElement("p"));
        div.appendChild(ancorGender);
        div.style.display = 'block';
    }

    function LoadAddressKeys(obj, divAddressDetails) {
        divAddressDetails.innerHTML = '';
        var ancorKeys = document.createElement("a");
        ancorKeys.innerHTML = "Address Details";
        ancorKeys.onclick = function () {
            loadAddressDetails(obj);
        }
        divAddressDetails.appendChild(ancorKeys);
        divAddressDetails.appendChild(document.createElement("p"));
        divAddressDetails.style.display = 'block';
    }

    function loadAddressDetails(obj)
    {
        var div = document.getElementById("Divselect");;
        div.innerHTML = '';

        var ancorHome = document.createElement("a");
        ancorHome.innerHTML = obj.HomeAddress;

        var ancorWork = document.createElement("a");
        ancorWork.innerHTML = obj.WorkAddress;

        div.appendChild(ancorHome);
        div.appendChild(document.createElement("p"));
        div.appendChild(ancorWork);
        div.style.display = 'block';
    }

}

})();