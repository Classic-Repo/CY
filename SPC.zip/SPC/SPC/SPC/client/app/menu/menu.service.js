﻿(function () {
    'use strict';

    angular
        .module('app.menu')
        .factory('menuService', menuService);

    menuService.$inject = ['$http'];

    function menuService($http) {
        var endPoint = 'http://localhost:54868/ConfigurationSettings/';

        return {
            getSettings: getSettings
        };

        function getSettings() {
            return $http.get(endPoint + '/GetSettings').then(function (response) {
                return response.data;
            });
        }
    }

})();