﻿angular
    .module('app', ['app.core', 'app.menu']);