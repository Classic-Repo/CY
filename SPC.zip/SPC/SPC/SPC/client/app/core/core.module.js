﻿(function () {
    'use strict';

    angular.module('app.core', ['ngRoute', 'ngResource']);
})();