﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SPCApi.Models
{
    public class Client
    {
        public Dictionary<string, string> PersonalDetails { get; set; }
        public Dictionary<string, string> AddresDetails { get; set; }
    }
}
