﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SPCApi.Models
{
    public class ConfigurationSettings
    {
        public Dictionary<string,Client> client { get ;set;}
        public Dictionary<string, string> bank { get; set; }
    }
}
