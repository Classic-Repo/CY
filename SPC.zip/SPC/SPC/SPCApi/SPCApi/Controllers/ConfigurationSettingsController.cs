﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SPCApi.Models;
using System.Net;
using System.Net.Http;

namespace SPCApi.Controllers
{
    [Route("[controller]")]
    public class ConfigurationSettingsController : Controller
    {

        private ConfigurationSettings ConfigurationSettings { get; set; }
        public HttpResponseMessage Options()
        {
            var response = new HttpResponseMessage();
            response.StatusCode = HttpStatusCode.OK;
            return response;
        }
        public ConfigurationSettingsController(IOptions<ConfigurationSettings> settings)
        {
            ConfigurationSettings = settings.Value;
        }
        [Route("GetSettings")]
        [HttpGet]
        public ConfigurationSettings GetSettings()
        {
            return ConfigurationSettings;
        }
    }
}
