﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutSurance.Classes;
using System.Windows.Forms;

namespace OutSurance.Implementation
{
    public class Reader : Abstraction.IReader
    {
        public bool Read()
        {
            bool Result = false;

            List<Classes.DataObject> Lte = new List<Classes.DataObject>();

            using (OpenFileDialog dg = new OpenFileDialog())
            {
                if (dg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    using (System.IO.StreamReader sr = new System.IO.StreamReader(dg.FileName))
                    {
                        while (sr.Peek() != -1)
                        {
                            string[] arr = sr.ReadLine().ToString().Split(new char[] { ',' });

                            Lte.Add(new Classes.DataObject { FirstName = arr[0], LastName = arr[1], Address = arr[2], PhoneNumber = arr[3] });
                        }
                    }

                    Lte.RemoveAt(0);

                    List<string[]> LteFile1Write = new List<string[]>();

                    List<Classes.DataObject> File1Write = Lte.Select(x => new Classes.DataObject { FirstName = x.FirstName, LastName = x.LastName }).ToList();

                    File1Write.ForEach(x =>
                    {
                        LteFile1Write.Add(new string[] { x.FirstName, File1Write.Count(j=> j.FirstName == x.FirstName).ToString() });
                        LteFile1Write.Add(new string[] { x.LastName, File1Write.Count(j => j.LastName == x.LastName).ToString() });
                    });

                    LteFile1Write = LteFile1Write.OrderBy(j => j[0]).OrderByDescending(x => x[1]).ToList();

                    using (System.IO.StreamWriter sw = new System.IO.StreamWriter(System.IO.Path.Combine(new System.IO.FileInfo(dg.FileName).DirectoryName,"FirstFile.txt"), false))
                    {
                        foreach (var val in LteFile1Write)
                        {
                            sw.WriteLine(val[0] +", "+ val[1]);
                        }

                        Result = true;
                    }

                    List<string[]> LteFile2Write = new List<string[]>();

                    List<Classes.DataObject>  File2Write =  Lte.Select(x => new Classes.DataObject { Address = x.Address }).ToList();

                    File2Write.ForEach(x =>
                    {
                        LteFile2Write.Add(x.Address.Split(new char[] { ' ' }));
                    });

                    LteFile2Write = LteFile2Write.OrderBy(x => x[1]).ToList();

                    using (System.IO.StreamWriter sw = new System.IO.StreamWriter(System.IO.Path.Combine(new System.IO.FileInfo(dg.FileName).DirectoryName, "SecondFile.txt"), false))
                    {
                        foreach (var val in LteFile2Write)
                        {
                            sw.WriteLine(val[0] + " " + val[1] + " " + val[2]);
                        }

                        Result = true;
                    }
                }
            }

            return Result;
        }



    }
}
