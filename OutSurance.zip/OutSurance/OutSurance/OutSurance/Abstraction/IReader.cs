﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OutSurance.Classes;

namespace OutSurance.Abstraction
{
    public interface IReader
    {
        bool Read();
    }
}
