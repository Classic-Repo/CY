﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OutSurance
{
    public partial class OutSurance : Form
    {
        public OutSurance()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                Abstraction.IReader Reader = new Implementation.Reader();
               if (Reader.Read())
                    MessageBox.Show("Done: Please see files in the same directory");

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"Error" , MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
