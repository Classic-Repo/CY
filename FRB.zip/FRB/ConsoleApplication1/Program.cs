﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string StrPrimeNumberPosition = "1000";

            if (args.Length >  0)
            {
                StrPrimeNumberPosition = args[0].ToString();
            }

                List<int> LTE = new List<int>();
                int PrimeNumberPosition;
                int.TryParse(StrPrimeNumberPosition, out PrimeNumberPosition);

                for (int i = 2; ; i++)
                {

                    bool Prime = true;

                    foreach (int j in LTE)
                    {
                        if (Convert.ToDouble(i % j) == 0)
                        {
                            Prime = false;
                        }
                    }

                    if (Prime)
                    {
                        LTE.Add(i);
                    }

                    if (LTE.Count == PrimeNumberPosition)
                    {
                        Console.WriteLine(i.ToString());
                        Console.Read();
                        LTE.Clear();
                        break;
                    }

                }

            

        }
      
    }
}
