/*
 * Public API Surface of demo-lib
 */

export * from './lib/demo-lib.service';
export * from './lib/demo-lib.component';
export * from './lib/demo-lib.module';
