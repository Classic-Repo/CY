﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Calculator.Implementation;
using Calculator.Abstraction;
using System.Globalization;

namespace Calculator
{
    public partial class frmCalculator : Form
    {

        private OperationObject ResultantValue { get; set; } = new OperationObject();
        private OperationObject HandlerObject { get; set; } = new OperationObject();
        private OperationObject ReserverObject { get; set; } = new OperationObject();

        private OperationType OperationType { get; set; } = OperationType.None;

        private Classes.Calculator Cal = new Classes.Calculator();
        private string ConcatenatedValue { get; set; } = string.Empty;

        private string MinusString { get; set; } = string.Empty;

        public frmCalculator()
        {
            InitializeComponent();

            foreach (var btn in pnCalculator.Controls)
            {
                if (btn is Button)
                {

                  Button TempBtn = (Button)btn;

                  TempBtn.Click += (sender, e) => {

                  Model Opbj = Cal.CalculatorModels.Where(x => x.Sender == TempBtn.Name).FirstOrDefault();

                      if (Opbj != null)
                      {
                          var TempConcatenatedValue = (ConcatenatedValue + "" + (((OperationObject)Opbj.Value).Value == (double)CalculatorValue.Dot ? "." :
                                                                                  ((OperationObject)Opbj.Value).Value.ToString())).ToString();

                          if (OperationType == OperationType.Minus)
                          {
                              ConcatenatedValue = MinusString + TempConcatenatedValue;
                              MinusString = string.Empty;
                          }
                          else
                              ConcatenatedValue = TempConcatenatedValue;
                         
                          if (((OperationObject)Opbj.Value).Value != (double)CalculatorValue.Dot)
                          {
                              HandlerObject.Value = Convert.ToDouble(ConcatenatedValue, CultureInfo.InvariantCulture);
                          }
                          
                          lblResult.Text = ConcatenatedValue;
                      }

                    };
                }
            }

            foreach (var btn in pnOperation.Controls)
            {

                if (btn is Button)
                {
                    Button TempBtn = (Button)btn;
                    
                    if (TempBtn.Name == "btnPlus")
                    {
                        TempBtn.Click += (sender, e) =>
                        {
                            OperationType = OperationType.Plus;
                            CalculateOperationResult();
                        };
                    }
                    else if (TempBtn.Name == "btnMinus")
                    {
                        TempBtn.Click += (sender, e) =>
                        {
                           
                            MinusString = OperationType == OperationType.None ? "-" : MinusString;

                            OperationType = OperationType.Minus;

                            CalculateOperationResult();
                        };
                    }
                    else if (TempBtn.Name == "btnDivide")
                    {
                        TempBtn.Click += (sender, e) =>
                        {
                            OperationType = OperationType.Divide;
                            CalculateOperationResult();
                        };
                    }
                    else if (TempBtn.Name == "btnMultiply")
                    {
                        TempBtn.Click += (sender, e) =>
                        {
                            OperationType = OperationType.Multiply;
                            CalculateOperationResult();
                        };
                    }

                }
            }
        }
       
        private void btnEqual_Click(object sender, EventArgs e)
        {
            if (OperationType == OperationType.Plus)
            {
                CalculateOperationResult();
                ResultantValue.Value += ReserverObject.Value;
            }
            else if (OperationType == OperationType.Minus)
            {
                CalculateOperationResult();
                ResultantValue.Value = ResultantValue.Value == 0? ReserverObject.Value: ((OperationObject)(ResultantValue - ReserverObject)).Value;
            }
            else if (OperationType == OperationType.Divide)
            {
                CalculateOperationResult();
                ResultantValue.Value = ResultantValue.Value == 0 ? ReserverObject.Value : ((OperationObject)(ResultantValue / ReserverObject)).Value;
            }
            else if (OperationType == OperationType.Multiply)
            {
                CalculateOperationResult();
                ResultantValue.Value = ResultantValue.Value == 0 ? ReserverObject.Value : ((OperationObject)(ResultantValue * ReserverObject)).Value;
            }
            else
            {
                MessageBox.Show("Invalid calculation", "Calculations", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            lblResult.Text = ResultantValue.Value.ToString();
            ReserverObject = new OperationObject();
            HandlerObject = new OperationObject();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            CleanValues();
            lblResult.Text = ResultantValue.Value.ToString();
            Cal = new Classes.Calculator();
        }

        private void CleanValues()
        {
            ReserverObject = new OperationObject();
            HandlerObject = new OperationObject();
            ResultantValue = new OperationObject();
            OperationType = OperationType.None;
            ConcatenatedValue = string.Empty;
        }

        private void CalculateOperationResult()
        {

            if (OperationType == OperationType.Plus)
            {
                ReserverObject.Value = ReserverObject.Value == 0 ? HandlerObject.Value : ((OperationObject)(ReserverObject + HandlerObject)).Value;
                lblResult.Text = ReserverObject.Value.ToString();
            }
            else if (OperationType == OperationType.Minus)
            {
                ReserverObject.Value = ReserverObject.Value == 0 ? HandlerObject.Value : ((OperationObject)(ReserverObject - HandlerObject)).Value;
                lblResult.Text = ReserverObject.Value.ToString();
            }
            else if (OperationType == OperationType.Divide)
            {
                ReserverObject.Value = ReserverObject.Value == 0 ? HandlerObject.Value : ((OperationObject)(ReserverObject / HandlerObject)).Value;
                lblResult.Text = ReserverObject.Value.ToString();
            }
            else if (OperationType == OperationType.Multiply)
            {
                ReserverObject.Value = ReserverObject.Value == 0 ? HandlerObject.Value : ((OperationObject)(ReserverObject * HandlerObject)).Value;
                lblResult.Text = ReserverObject.Value.ToString();
            }

            HandlerObject.Value = 0;
            ConcatenatedValue = string.Empty;

        }

    }
}
