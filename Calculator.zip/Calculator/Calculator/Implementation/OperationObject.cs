﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Abstraction;

namespace Calculator.Implementation
{
    public class OperationObject : IOperationObjectValue
    {
        public double Value { get; set; }

        public static IOperationObjectValue operator +(OperationObject FirstParam, OperationObject SecondParam) =>
        new OperationObject { Value = FirstParam.Value + SecondParam.Value };

        public static IOperationObjectValue operator -(OperationObject FirstParam, OperationObject SecondParam) =>
        new OperationObject { Value = FirstParam.Value - SecondParam.Value };

        public static IOperationObjectValue operator /(OperationObject FirstParam, OperationObject SecondParam) =>
        new OperationObject { Value = FirstParam.Value / SecondParam.Value };

        public static IOperationObjectValue operator *(OperationObject FirstParam, OperationObject SecondParam) =>
        new OperationObject { Value = FirstParam.Value * SecondParam.Value };


    }
}
