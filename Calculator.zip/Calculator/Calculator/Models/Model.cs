﻿using Calculator.Abstraction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public enum CalculatorValue : byte { Zero = 0, One = 1, Two = 2, Three = 3, Four = 4, Five = 5, Six = 6, Seven = 7, Eight = 8, Nine = 9, Dot = 10 }

    public enum OperationType : byte {None = 0, Plus=1, Minus = 2, Divide = 3, Multiply = 4}
    public class Model
    {
        public string Sender { get; set; } = string.Empty;

        public IOperationObjectValue Value { get; set; }
    }
}
