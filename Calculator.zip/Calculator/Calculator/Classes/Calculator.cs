﻿using Calculator.Abstraction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculator.Implementation;

namespace Calculator.Classes
{
    public class Calculator
    {
      public List<Model> CalculatorModels = new List<Model> {
           new Model { Sender = "btnZero", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Zero)} },
           new Model { Sender = "btnOne" , Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.One) } },
           new Model { Sender = "btnTwo", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Two) } },
           new Model { Sender = "btnThree", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Three) } },
           new Model { Sender = "btnFour", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Four) } },
           new Model { Sender = "btnFive", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Five) } },
           new Model { Sender = "btnSix", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Six) } },
           new Model { Sender = "btnSeven", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Seven) } },
           new Model { Sender = "btnEight", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Eight) } },
           new Model { Sender = "btnNine", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Nine) } },
           new Model { Sender = "btnDot", Value = new OperationObject { Value = Convert.ToDouble(CalculatorValue.Dot) } }
        };
    }
}
